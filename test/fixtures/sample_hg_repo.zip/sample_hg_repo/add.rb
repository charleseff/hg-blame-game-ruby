module Add
  def add_4(y)
    y + 5
  end
end