$:.unshift(File.dirname(__FILE__))
require 'add'
include Add

puts add_4(9) # should be 13